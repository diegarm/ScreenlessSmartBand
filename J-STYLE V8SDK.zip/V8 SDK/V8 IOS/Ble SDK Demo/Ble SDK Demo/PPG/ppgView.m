//
//  ppgView.m
//  Ble SDK Demo
//
//  Created by yang sai on 2022/7/8.
//

#import "ppgView.h"
#import "CustomeChartView.h"
#define testTime 300
@interface ppgView ()<MyBleDelegate>
{
    int myMeasurementTime;
    BOOL isMeasurment;
    CustomeChartView * chartView_PPG;
    NSMutableArray * arrayPPGData;
    NSMutableArray * arrayAllPPGData;
    NSTimer * myTimer;
    
    NSMutableArray * arrayECGData;
    NSMutableArray * arraySignal;
    
    
    
    
}
@property (weak, nonatomic) IBOutlet UIButton *btnStart;
@property (weak, nonatomic) IBOutlet UIButton *btnStop;
@property (weak, nonatomic) IBOutlet UILabel *labProgress;
@property (weak, nonatomic) IBOutlet UIButton *btnQuit;

@property (weak, nonatomic) IBOutlet UILabel *labLoseBageName;
@property (weak, nonatomic) IBOutlet UILabel *labLoseBageValue;
@property (weak, nonatomic) IBOutlet UILabel *labLoseBageName_5s;
@property (weak, nonatomic) IBOutlet UILabel *labLoseBageValue_5s;

@property (weak, nonatomic) IBOutlet UILabel *labMaxName;
@property (weak, nonatomic) IBOutlet UILabel *labMaxValue;
@property (weak, nonatomic) IBOutlet UILabel *labMinName;
@property (weak, nonatomic) IBOutlet UILabel *labMinValue;


@property (nonatomic, strong) NSMutableArray<NSNumber *> *lostTimestamps;


@end


@implementation ppgView


- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    arrayPPGData = [[NSMutableArray alloc] init];
    arrayAllPPGData = [[NSMutableArray alloc] init];
    [NewBle sharedManager].delegate = self;
    [self addECGAndPPGView];
    [self myMasonry];
    isMeasurment = NO;
    
    
    _lostTimestamps = [NSMutableArray array];

    
}


-(void)myMasonry
{
    [_btnStart mas_makeConstraints:^(MASConstraintMaker * make)
     {
        make.left.mas_equalTo(self.view.mas_left).offset(10*Proportion);
        make.top.mas_equalTo(self.view.mas_top).offset(125*Proportion);
        make.width.mas_equalTo(150*Proportion);
        make.height.mas_equalTo(50*Proportion);
    }];
    [_btnStop mas_makeConstraints:^(MASConstraintMaker * make)
     {
        make.right.mas_equalTo(self.view.mas_right).offset(-10*Proportion);
        make.centerY.mas_equalTo(_btnStart.mas_centerY);
        make.width.mas_equalTo(150*Proportion);
        make.height.mas_equalTo(50*Proportion);
    }];
    
    
    NSArray *views = @[_labLoseBageName, _labLoseBageValue, _labLoseBageName_5s,_labLoseBageValue_5s];

    [views mas_distributeViewsAlongAxis:MASAxisTypeHorizontal
                      withFixedItemLength:88*Proportion
                              leadSpacing:10
                              tailSpacing:10];

    [views mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_btnStart.mas_bottom).offset(10*Proportion );
        make.height.mas_equalTo(25*Proportion);
    }];
    
    
//    [_btnQuit mas_makeConstraints:^(MASConstraintMaker * make)
//     {
//        make.right.mas_equalTo(self.view.mas_right).offset(-12*Proportion);
//        make.centerY.mas_equalTo(_btnStart.mas_centerY);
//        make.width.mas_equalTo(100*Proportion);
//        make.height.mas_equalTo(50*Proportion);
//    }];
//    [_labProgress mas_makeConstraints:^(MASConstraintMaker * make)
//     {
//        make.centerX.mas_equalTo(self.view.mas_centerX);
//        make.top.mas_equalTo(_btnStart.mas_bottom).offset(10*Proportion);
//        make.width.mas_equalTo(150*Proportion);
//        make.height.mas_equalTo(25*Proportion);
//    }];
    NSArray *views1 = @[_labMaxName, _labMaxValue, _labMinName,_labMinValue];

    [views1 mas_distributeViewsAlongAxis:MASAxisTypeHorizontal
                      withFixedItemLength:88*Proportion
                              leadSpacing:10
                              tailSpacing:10];

    [views1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_labLoseBageName.mas_bottom).offset(10*Proportion );
        make.height.mas_equalTo(25*Proportion);
    }];

}


#pragma mark addECGAndPPGView
-(void)addECGAndPPGView
{

    chartView_PPG = [[CustomeChartView alloc] initWithFrame:CGRectMake(0, 260*Proportion,Width,400*Proportion) WithSingleNumber:255 WithMaxSeconds:5];
    //fb0e3b
    chartView_PPG.LineColor = [UIColor colorWithRed:0xfb/255.0 green:0x0e/255.0 blue:0x3b/255.0 alpha:1];
    chartView_PPG.LineWidth = 1.0;
    chartView_PPG.blankCount = 200;
    chartView_PPG.DataBase = 2;
    [self.view addSubview:chartView_PPG];

}


#pragma mark MyBleDelegate
-(void)ConnectSuccessfully
{
    
}
-(void)Disconnect:(NSError *_Nullable)error
{
    [PishumToast showToastWithMessage:LocalForkey(@"设备断开连接") Length:TOAST_SHORT ParentView:self.view];
}
-(void)scanWithPeripheral:(CBPeripheral*_Nonnull)peripheral advertisementData:(NSDictionary<NSString *, id> *_Nonnull)advertisementData RSSI:(NSNumber *_Nonnull)RSSI
{
    
}
-(void)ConnectFailedWithError:(nullable NSError *)error
{
    
}
-(void)EnableCommunicate
{
    
}

-(void)BleCommunicateWithPeripheral:(CBPeripheral*)Peripheral data:(NSData *)data
{
    
    
    DeviceData_V8 * deviceData = [[DeviceData_V8 alloc] init];
    deviceData  = [[BleSDK_V8 sharedManager] DataParsingWithData:data];
    
    
    if(deviceData.dataType == DeviceMeasurement_V8)
    {
        NSMutableData * data = [[BleSDK_V8 sharedManager] setECGRealtimeDuringHRVEnabled:isMeasurment];
        [[NewBle sharedManager] writeValue:SERVICE characteristicUUID:SEND_CHAR p:[NewBle sharedManager].activityPeripheral data:data];
    }
    else if (deviceData.dataType==ECG_RawData_V8)
    {
        NSDictionary * dicEcgData = deviceData.dicData;
        NSArray * arrayEcg = dicEcgData[@"arrayEcgRawData"];
        NSNumber * packetID = dicEcgData[@"packetID"];
        [chartView_PPG addShowDatasECG:arrayEcg];
    }
}





- (void)receivePacketID:(uint8_t)packetID {
    if (!self.hasLast) {
        self.lastID = packetID;
        self.hasLast = YES;
        return;
    }

    uint8_t expected = (self.lastID + 1) & 0xFF;

    if (packetID != expected) {
        uint8_t lost = (packetID - expected) & 0xFF;

        self.totalLostCount += lost;

        NSTimeInterval now = CACurrentMediaTime();
        for (int i = 0; i < lost; i++) {
            [self.lostTimestamps addObject:@(now)];
        }
    }

    self.lastID = packetID;
}


- (NSUInteger)lostCountInLast5Seconds {
    NSTimeInterval now = CACurrentMediaTime();
    NSTimeInterval window = 5.0;

    NSUInteger count = 0;
    NSMutableArray *expired = [NSMutableArray array];

    for (NSNumber *ts in self.lostTimestamps) {
        if (now - ts.doubleValue <= window) {
            count++;
        } else {
            [expired addObject:ts];
        }
    }

    // 清理过期时间戳（防止数组无限增长）
    [self.lostTimestamps removeObjectsInArray:expired];

    return count;
}


#pragma mark 倒计时
-(void)showLabTime
{
    if(myMeasurementTime<=testTime){
        
        
       
        
        NSString * progressValue = [NSString stringWithFormat:@"%.0f%%",(myMeasurementTime/(float)testTime*100)];
        _labProgress.text = progressValue ;
        
        myMeasurementTime +=1;
    }
    else
    {
      
        
        if([myTimer isValid])
        {
            [myTimer invalidate];
            myTimer = nil;
        }
        isMeasurment = NO;

    }
}


 
  

    
    



- (IBAction)start:(UIButton *)sender {
    if([[NewBle sharedManager] isConnectOrConnecting]==YES){
     
        if(!arraySignal)
        arraySignal = [[NSMutableArray alloc] init];
        if(!arrayECGData)
        arrayECGData = [[NSMutableArray alloc] init];
        [arraySignal removeAllObjects];
        [arrayECGData removeAllObjects];
        isMeasurment = YES;
      NSMutableData * data = [[BleSDK_V8 sharedManager] manualMeasurementWithDataType:hrvData_v8 measurementTime:testTime open:isMeasurment];
        [[NewBle sharedManager] writeValue:SERVICE characteristicUUID:SEND_CHAR p:[NewBle sharedManager].activityPeripheral data:data];
        
    }
    else
        [PishumToast showToastWithMessage:LocalForkey(@"设备未连接") Length:TOAST_SHORT ParentView:self.view];
    
}

- (IBAction)stop:(UIButton *)sender {
    if([[NewBle sharedManager] isConnectOrConnecting]==YES){
        isMeasurment = NO;
       NSMutableData * data = [[BleSDK_V8 sharedManager] manualMeasurementWithDataType:hrvData_v8 measurementTime:testTime open:isMeasurment];
        [[NewBle sharedManager] writeValue:SERVICE characteristicUUID:SEND_CHAR p:[NewBle sharedManager].activityPeripheral data:data];
    }
    else
        [PishumToast showToastWithMessage:LocalForkey(@"设备未连接") Length:TOAST_SHORT ParentView:self.view];
}
- (IBAction)quit:(UIButton *)sender {
    if([[NewBle sharedManager] isConnectOrConnecting]==YES){
     
    }
    else
        [PishumToast showToastWithMessage:LocalForkey(@"设备未连接") Length:TOAST_SHORT ParentView:self.view];
}

- (IBAction)setBaseLine:(UIButton *)sender {\
    
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"设置基线"
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];

    // 添加输入框
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"基线值";
        textField.keyboardType = UIKeyboardTypeNumberPad;   // 键盘类型
        textField.secureTextEntry = NO;                    // 密码用 YES
    }];

    // 确认按钮
    UIAlertAction *okAction =
    [UIAlertAction actionWithTitle:@"确定"
                             style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * _Nonnull action) {

        UITextField *textField = alert.textFields.firstObject;
        NSString *inputText = textField.text;
        chartView_PPG.DataBase = inputText.intValue;
        NSLog(@"输入内容：%@", inputText);
    }];

    // 取消按钮
    UIAlertAction *cancelAction =
    [UIAlertAction actionWithTitle:@"取消"
                             style:UIAlertActionStyleCancel
                           handler:nil];

    [alert addAction:cancelAction];
    [alert addAction:okAction];

    // 弹出
    [self presentViewController:alert animated:YES completion:nil];
}


- (IBAction)back:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
