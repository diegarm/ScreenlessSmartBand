//
//  ppgView.h
//  Ble SDK Demo
//
//  Created by yang sai on 2022/7/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ppgView : UIViewController

@property (nonatomic, assign) uint8_t lastID;
@property (nonatomic, assign) BOOL hasLast;

@property (nonatomic, assign) NSUInteger totalLostCount;

- (void)receivePacketID:(uint8_t)packetID;
- (NSUInteger)lostCountInLast5Seconds;
@end

NS_ASSUME_NONNULL_END
